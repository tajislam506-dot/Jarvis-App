Jarvis Android App Project (Full)
=================================

এই প্রজেক্টে আপনার আসল `Jarvis-App (1).html` ফাইল assets ফোল্ডারে বসানো হয়েছে।

কীভাবে ব্যবহার করবেন
-------------------
1) Android Studio তে এই প্রজেক্ট ওপেন করুন।
2) Build > Build APK(s) এ যান।
3) APK তৈরি হবে, সেটা আপনার ফোনে ইনস্টল করুন।

অ্যাপ খুললেই Jarvis (ChatGPT-style) চালু হবে WebView এর মধ্যে।
